//Tupeles

 

let fullname = ("Yatharth","Chauhan") //String, String
print(fullname.1)


let (first,last) = ("Ashish", "patel")
print(first)


let (f1, _) = ("as", "you")
print(f1)

