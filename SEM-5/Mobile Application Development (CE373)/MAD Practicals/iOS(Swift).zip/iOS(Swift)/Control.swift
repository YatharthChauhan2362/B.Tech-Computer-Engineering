if 10 > 5{

print("10 is greater then 5")
}else{

print("10 is not greater then 5")
}