//Switch

let name1 = "Yatharth"
// let name1 = "any" //Goings in default section
switch name1 {



case "Yatharth":
print("Name is Yatharth")
case "Ashish":
print("name is Ashish")
default:
print("IDK")
}