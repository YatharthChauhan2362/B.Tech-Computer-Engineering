let str = "Hello World" 
print(str)

var mainstr = "Yatharth"
print(mainstr)

mainstr = "Chauhan"
print(mainstr)



let emprystr = ""

if emprystr.isEmpty{
print("\nEmpty")

}

else{
print("\not empty")
}



var v1 = "Hello1"
var v2 = "Hello"
if (v1 == v2) {

    print("\n\(v1) and \(v2) is equal")
}
else{

print("\n\(v1) and \(v2) is not equal")
}




